import { ScrollView, Text, View, TouchableOpacity, TextInput, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";

export default function LoginScreen() {
  const colors = useColors();
  const router = useRouter();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    setIsLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      await login(email, password);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace("/(tabs)");
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary px-6 pt-12 pb-8">
          <Text className="text-3xl font-bold text-white mb-2">Welcome Back</Text>
          <Text className="text-sm text-white opacity-80">Sign in to your Mobile Shield account</Text>
        </View>

        {/* Form */}
        <View className="px-6 py-8 flex-1">
          {/* Email Input */}
          <View className="mb-6">
            <Text className="text-sm font-semibold text-foreground mb-2">Email Address</Text>
            <View
              className="flex-row items-center border rounded-12 px-4 py-3"
              style={{ borderColor: colors.border, borderWidth: 1 }}
            >
              <IconSymbol size={20} name="person.fill" color={colors.muted} />
              <TextInput
                placeholder="you@example.com"
                placeholderTextColor={colors.muted}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                editable={!isLoading}
                style={{
                  flex: 1,
                  marginLeft: 12,
                  color: colors.foreground,
                  fontSize: 16,
                }}
              />
            </View>
          </View>

          {/* Password Input */}
          <View className="mb-2">
            <Text className="text-sm font-semibold text-foreground mb-2">Password</Text>
            <View
              className="flex-row items-center border rounded-12 px-4 py-3"
              style={{ borderColor: colors.border, borderWidth: 1 }}
            >
              <IconSymbol size={20} name="lock.fill" color={colors.muted} />
              <TextInput
                placeholder="Enter your password"
                placeholderTextColor={colors.muted}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                editable={!isLoading}
                style={{
                  flex: 1,
                  marginLeft: 12,
                  color: colors.foreground,
                  fontSize: 16,
                }}
              />
              <Pressable
                onPress={() => setShowPassword(!showPassword)}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <IconSymbol size={20} name="eye.fill" color={colors.muted} />
              </Pressable>
            </View>
          </View>

          {/* Forgot Password */}
          <TouchableOpacity
            onPress={() => router.push("../forgot-password")}
            style={{ marginBottom: 24 }}
          >
            <Text className="text-sm font-semibold text-primary">Forgot Password?</Text>
          </TouchableOpacity>

          {/* Login Button */}
          <TouchableOpacity
            onPress={handleLogin}
            disabled={isLoading}
            style={{
              backgroundColor: colors.primary,
              borderRadius: 12,
              padding: 16,
              marginBottom: 12,
              opacity: isLoading ? 0.6 : 1,
            }}
          >
            <Text className="text-center font-semibold text-white text-base">
              {isLoading ? "Signing in..." : "Sign In"}
            </Text>
          </TouchableOpacity>

          {/* Gmail Button */}
          <TouchableOpacity
            disabled={isLoading}
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderWidth: 1,
              borderRadius: 12,
              padding: 16,
              marginBottom: 24,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              opacity: isLoading ? 0.6 : 1,
            }}
          >
            <Text className="text-center font-semibold text-foreground text-base">
              Sign in with Gmail
            </Text>
          </TouchableOpacity>

          {/* Divider */}
          <View className="flex-row items-center mb-6">
            <View className="flex-1 h-px" style={{ backgroundColor: colors.border }} />
            <Text className="text-xs text-muted mx-3">Don't have an account?</Text>
            <View className="flex-1 h-px" style={{ backgroundColor: colors.border }} />
          </View>

          {/* Sign Up Button */}
          <TouchableOpacity
            onPress={() => router.push("../register")}
            disabled={isLoading}
            style={{
              backgroundColor: colors.primary + "20",
              borderColor: colors.primary,
              borderWidth: 2,
              borderRadius: 12,
              padding: 16,
              opacity: isLoading ? 0.6 : 1,
            }}
          >
            <Text className="text-center font-semibold text-primary text-base">Create New Account</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View className="px-6 py-6 border-t" style={{ borderColor: colors.border, borderTopWidth: 1 }}>
          <Text className="text-xs text-muted text-center">
            By signing in, you agree to our Terms of Service and Privacy Policy
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
