import { ScrollView, Text, View, TouchableOpacity, TextInput } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { useState } from "react";

export default function ForgotPasswordScreen() {
  const colors = useColors();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleReset = async () => {
    if (!email) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    setIsLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500));
      setIsSubmitted(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary px-6 pt-12 pb-8">
          <Text className="text-3xl font-bold text-white mb-2">Reset Password</Text>
          <Text className="text-sm text-white opacity-80">We'll help you recover your account</Text>
        </View>

        {/* Content */}
        <View className="px-6 py-8 flex-1">
          {!isSubmitted ? (
            <>
              {/* Email Input */}
              <View className="mb-8">
                <Text className="text-sm font-semibold text-foreground mb-4">
                  Enter your email address and we'll send you a link to reset your password.
                </Text>

                <Text className="text-sm font-semibold text-foreground mb-2">Email Address</Text>
                <View
                  className="flex-row items-center border rounded-12 px-4 py-3"
                  style={{ borderColor: colors.border, borderWidth: 1 }}
                >
                  <IconSymbol size={20} name="person.fill" color={colors.muted} />
                  <TextInput
                    placeholder="you@example.com"
                    placeholderTextColor={colors.muted}
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    editable={!isLoading}
                    style={{
                      flex: 1,
                      marginLeft: 12,
                      color: colors.foreground,
                      fontSize: 16,
                    }}
                  />
                </View>
              </View>

              {/* Info Box */}
              <View className="bg-primary opacity-10 rounded-2xl p-4 border border-primary mb-8">
                <View className="flex-row items-start">
                  <IconSymbol size={20} name="exclamationmark.triangle.fill" color={colors.primary} />
                  <View className="flex-1 ml-3">
                    <Text className="text-sm font-semibold text-foreground">Check your email</Text>
                    <Text className="text-xs text-muted mt-1">
                      We'll send you a password reset link. Check your spam folder if you don't see it.
                    </Text>
                  </View>
                </View>
              </View>

              {/* Send Button */}
              <TouchableOpacity
                onPress={handleReset}
                disabled={isLoading}
                style={{
                  backgroundColor: colors.primary,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 12,
                  opacity: isLoading ? 0.6 : 1,
                }}
              >
                <Text className="text-center font-semibold text-white text-base">
                  {isLoading ? "Sending..." : "Send Reset Link"}
                </Text>
              </TouchableOpacity>

              {/* Back Button */}
              <TouchableOpacity
                onPress={() => router.back()}
                disabled={isLoading}
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderWidth: 1,
                  borderRadius: 12,
                  padding: 16,
                  opacity: isLoading ? 0.6 : 1,
                }}
              >
                <Text className="text-center font-semibold text-foreground text-base">Back to Login</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              {/* Success Message */}
              <View className="items-center py-12">
                <View
                  className="w-24 h-24 rounded-full items-center justify-center mb-6"
                  style={{ backgroundColor: colors.success + "20" }}
                >
                  <IconSymbol size={48} name="checkmark.circle.fill" color={colors.success} />
                </View>

                <Text className="text-2xl font-bold text-foreground text-center mb-2">Check Your Email</Text>
                <Text className="text-sm text-muted text-center mb-8">
                  We've sent a password reset link to {email}. Click the link in the email to reset your password.
                </Text>

                <View className="bg-surface rounded-2xl p-4 border border-border w-full mb-8">
                  <Text className="text-sm font-semibold text-foreground mb-2">Didn't receive the email?</Text>
                  <Text className="text-xs text-muted mb-4">
                    Check your spam folder or try using a different email address.
                  </Text>
                  <TouchableOpacity
                    onPress={() => {
                      setIsSubmitted(false);
                      setEmail("");
                    }}
                  >
                    <Text className="text-sm font-semibold text-primary">Try Again</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Return Button */}
              <TouchableOpacity
                onPress={() => router.replace("../login")}
                style={{
                  backgroundColor: colors.primary,
                  borderRadius: 12,
                  padding: 16,
                }}
              >
                <Text className="text-center font-semibold text-white text-base">Return to Login</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
