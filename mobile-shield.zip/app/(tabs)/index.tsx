import { ScrollView, Text, View, TouchableOpacity, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { useState } from "react";

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const [securityStatus, setSecurityStatus] = useState<"safe" | "warning" | "danger">("safe");
  const [isPremium, setIsPremium] = useState(false);

  const handleQuickAction = (action: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (action === "scan") {
      router.push("../scan");
    } else if (action === "upgrade") {
      router.push("../features");
    } else if (action === "settings") {
      router.push("../settings");
    }
  };

  const getStatusColor = () => {
    switch (securityStatus) {
      case "safe":
        return colors.success;
      case "warning":
        return colors.warning;
      case "danger":
        return colors.error;
    }
  };

  const getStatusText = () => {
    switch (securityStatus) {
      case "safe":
        return "Your device is secure";
      case "warning":
        return "Potential threats detected";
      case "danger":
        return "Critical threats found";
    }
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Header Section */}
        <View className="bg-primary px-6 pt-6 pb-8">
          <View className="flex-row items-center justify-between mb-6">
            <View>
              <Text className="text-3xl font-bold text-white">Mobile Shield</Text>
              <Text className="text-sm text-white opacity-80 mt-1">Security. Elevated.</Text>
            </View>
            <Pressable
              onPress={() => router.push("../settings")}
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <IconSymbol size={28} name="bell.fill" color="white" />
            </Pressable>
          </View>

          {/* Security Status Card */}
          <View
            className="rounded-2xl p-6 border"
            style={{
              backgroundColor: colors.surface,
              borderColor: getStatusColor(),
              borderWidth: 2,
            }}
          >
            <View className="flex-row items-center justify-between mb-3">
              <Text className="text-lg font-semibold text-foreground">Security Status</Text>
              <IconSymbol size={24} name="checkmark.shield.fill" color={getStatusColor()} />
            </View>
            <Text className="text-sm text-muted mb-3">{getStatusText()}</Text>
            <View className="h-2 bg-border rounded-full overflow-hidden">
              <View
                className="h-full rounded-full"
                style={{
                  backgroundColor: getStatusColor(),
                  width: securityStatus === "safe" ? "100%" : securityStatus === "warning" ? "60%" : "30%",
                }}
              />
            </View>
            <Text className="text-xs text-muted mt-3">Last scan: 2 hours ago</Text>
          </View>
        </View>

        {/* Quick Actions */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-lg font-semibold text-foreground mb-4">Quick Actions</Text>

          {/* Single Scan - Free */}
          <Pressable
            onPress={() => handleQuickAction("scan")}
            style={({ pressed }) => [
              {
                backgroundColor: colors.surface,
                borderColor: colors.primary,
                borderWidth: 2,
                borderRadius: 16,
                padding: 16,
                marginBottom: 12,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-1">
                <View className="flex-row items-center mb-1">
                  <Text className="text-base font-semibold text-foreground">Scan File/App</Text>
                  <View className="bg-success rounded-full px-2 py-1 ml-2">
                    <Text className="text-xs font-bold text-white">FREE</Text>
                  </View>
                </View>
                <Text className="text-sm text-muted">Scan a single app or file for threats</Text>
              </View>
              <IconSymbol size={24} name="arrow.up.right" color={colors.primary} />
            </View>
          </Pressable>

          {/* Full Device Scan - Premium */}
          <Pressable
            onPress={() => {
              if (!isPremium) {
                handleQuickAction("upgrade");
              } else {
                handleQuickAction("scan");
              }
            }}
            style={({ pressed }) => [
              {
                backgroundColor: isPremium ? colors.surface : colors.primary + "20",
                borderColor: isPremium ? colors.primary : colors.warning,
                borderWidth: 2,
                borderRadius: 16,
                padding: 16,
                marginBottom: 12,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-1">
                <View className="flex-row items-center mb-1">
                  <Text className="text-base font-semibold text-foreground">Full Device Scan</Text>
                  <View className="bg-warning rounded-full px-2 py-1 ml-2">
                    <Text className="text-xs font-bold text-white">{isPremium ? "ACTIVE" : "PREMIUM"}</Text>
                  </View>
                </View>
                <Text className="text-sm text-muted">
                  {isPremium ? "Scan your entire device for threats" : "Upgrade to unlock full device scanning"}
                </Text>
              </View>
              <IconSymbol size={24} name="shield.fill" color={isPremium ? colors.primary : colors.warning} />
            </View>
          </Pressable>

          {/* Upgrade Plan */}
          {!isPremium && (
            <Pressable
              onPress={() => handleQuickAction("upgrade")}
              style={({ pressed }) => [
                {
                  backgroundColor: colors.primary,
                  borderRadius: 16,
                  padding: 16,
                  opacity: pressed ? 0.9 : 1,
                },
              ]}
            >
              <View className="flex-row items-center justify-between">
                <View className="flex-1">
                  <Text className="text-base font-semibold text-white mb-1">Upgrade to Premium</Text>
                  <Text className="text-sm text-white opacity-80">Unlock all security features</Text>
                </View>
                <IconSymbol size={24} name="arrow.up.right" color="white" />
              </View>
            </Pressable>
          )}
        </View>

        {/* Recent Activity */}
        <View className="px-6 py-4">
          <Text className="text-lg font-semibold text-foreground mb-4">Recent Activity</Text>

          <View className="bg-surface rounded-2xl p-4 border border-border">
            <View className="flex-row items-start mb-3">
              <View
                className="w-10 h-10 rounded-full items-center justify-center mr-3"
                style={{ backgroundColor: colors.success + "20" }}
              >
                <IconSymbol size={20} name="checkmark.circle.fill" color={colors.success} />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground">Device Scan Complete</Text>
                <Text className="text-xs text-muted mt-1">No threats detected • 2 hours ago</Text>
              </View>
            </View>

            <View className="flex-row items-start">
              <View
                className="w-10 h-10 rounded-full items-center justify-center mr-3"
                style={{ backgroundColor: colors.primary + "20" }}
              >
                <IconSymbol size={20} name="lock.fill" color={colors.primary} />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground">Thief Lock Activated</Text>
                <Text className="text-xs text-muted mt-1">App protection enabled • 1 day ago</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Tips Section */}
        <View className="px-6 py-4 pb-8">
          <Text className="text-lg font-semibold text-foreground mb-4">Security Tips</Text>

          <View className="bg-primary opacity-10 rounded-2xl p-4 border border-primary">
            <View className="flex-row items-start">
              <IconSymbol size={20} name="exclamationmark.triangle.fill" color={colors.primary} />
              <View className="flex-1 ml-3">
                <Text className="text-sm font-semibold text-foreground">Daily Security Check</Text>
                <Text className="text-xs text-muted mt-1">
                  Run a quick scan every morning to keep your device protected from threats.
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
