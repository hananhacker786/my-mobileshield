import { ScrollView, Text, View, TouchableOpacity, Pressable, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import * as Haptics from "expo-haptics";
import { useState } from "react";
import { FilePickerService, PickedFile, FileAnalysis } from "@/lib/file-picker-service";

export default function ScanScreen() {
  const colors = useColors();
  const [scanMode, setScanMode] = useState<"select" | "picking" | "scanning" | "results" | null>(null);
  const [scanProgress, setScanProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState<PickedFile | null>(null);
  const [analysisResult, setAnalysisResult] = useState<FileAnalysis | null>(null);

  const handlePickFile = async (type: "any" | "image" | "audio" | "video") => {
    setScanMode("picking");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    let file: PickedFile | null = null;

    try {
      switch (type) {
        case "image":
          file = await FilePickerService.pickImage();
          break;
        case "audio":
          file = await FilePickerService.pickAudio();
          break;
        case "video":
          file = await FilePickerService.pickVideo();
          break;
        default:
          file = await FilePickerService.pickFile();
      }

      if (file) {
        setSelectedFile(file);
        startScan(file);
      } else {
        setScanMode("select");
      }
    } catch (error) {
      console.error("Error picking file:", error);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setScanMode("select");
    }
  };

  const startScan = async (file: PickedFile) => {
    setScanMode("scanning");
    setScanProgress(0);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + Math.random() * 30;
      });
    }, 300);

    try {
      // Analyze the file
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const result = await FilePickerService.analyzeFile(file);
      setAnalysisResult(result);
      setScanMode("results");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error("Error analyzing file:", error);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setScanMode("select");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "safe":
        return colors.success;
      case "threat":
        return colors.error;
      case "suspicious":
        return colors.warning;
      default:
        return colors.muted;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "safe":
        return "checkmark.circle.fill";
      case "threat":
        return "xmark.circle.fill";
      case "suspicious":
        return "exclamationmark.triangle.fill";
      default:
        return "questionmark.circle.fill";
    }
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary px-6 pt-6 pb-8">
          <Text className="text-3xl font-bold text-white mb-2">Security Scan</Text>
          <Text className="text-sm text-white opacity-80">Detect threats in your device</Text>
        </View>

        {/* Content */}
        <View className="px-6 py-6">
          {scanMode === null ? (
            <>
              <Text className="text-lg font-semibold text-foreground mb-4">Choose Scan Type</Text>

              <Pressable
                onPress={() => setScanMode("select")}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.surface,
                    borderColor: colors.primary,
                    borderWidth: 2,
                    borderRadius: 16,
                    padding: 16,
                    marginBottom: 12,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <View className="flex-row items-center justify-between">
                  <View className="flex-1">
                    <View className="flex-row items-center mb-1">
                      <Text className="text-base font-semibold text-foreground">Scan File/App</Text>
                      <View className="bg-success rounded-full px-2 py-1 ml-2">
                        <Text className="text-xs font-bold text-white">FREE</Text>
                      </View>
                    </View>
                    <Text className="text-sm text-muted">Select and scan a file from your device</Text>
                  </View>
                  <IconSymbol size={24} name="arrow.up.right" color={colors.primary} />
                </View>
              </Pressable>

              <Pressable
                onPress={() => {
                  setScanMode("scanning");
                }}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.primary + "20",
                    borderColor: colors.warning,
                    borderWidth: 2,
                    borderRadius: 16,
                    padding: 16,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <View className="flex-row items-center justify-between">
                  <View className="flex-1">
                    <View className="flex-row items-center mb-1">
                      <Text className="text-base font-semibold text-foreground">Full Device Scan</Text>
                      <View className="bg-warning rounded-full px-2 py-1 ml-2">
                        <Text className="text-xs font-bold text-white">PREMIUM</Text>
                      </View>
                    </View>
                    <Text className="text-sm text-muted">Scan your entire device for threats</Text>
                  </View>
                  <IconSymbol size={24} name="shield.fill" color={colors.warning} />
                </View>
              </Pressable>

              <View className="bg-primary opacity-10 rounded-2xl p-4 border border-primary mt-6">
                <View className="flex-row items-start">
                  <IconSymbol size={20} name="exclamationmark.triangle.fill" color={colors.primary} />
                  <View className="flex-1 ml-3">
                    <Text className="text-sm font-semibold text-foreground">How Scanning Works</Text>
                    <Text className="text-xs text-muted mt-1">
                      Mobile Shield analyzes files for malware signatures, suspicious extensions, and unusual
                      characteristics.
                    </Text>
                  </View>
                </View>
              </View>
            </>
          ) : scanMode === "select" ? (
            <>
              <Text className="text-lg font-semibold text-foreground mb-4">Select File Type</Text>

              <TouchableOpacity
                onPress={() => handlePickFile("any")}
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderWidth: 2,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 12,
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <View
                  className="w-12 h-12 rounded-full items-center justify-center mr-3"
                  style={{ backgroundColor: colors.primary + "20" }}
                >
                  <IconSymbol size={24} name="arrow.up.right" color={colors.primary} />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Browse All Files</Text>
                  <Text className="text-xs text-muted mt-1">Select any file from your device</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => handlePickFile("image")}
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderWidth: 2,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 12,
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <View
                  className="w-12 h-12 rounded-full items-center justify-center mr-3"
                  style={{ backgroundColor: colors.primary + "20" }}
                >
                  <IconSymbol size={24} name="photo" color={colors.primary} />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Images</Text>
                  <Text className="text-xs text-muted mt-1">Scan image files</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => handlePickFile("audio")}
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderWidth: 2,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 12,
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <View
                  className="w-12 h-12 rounded-full items-center justify-center mr-3"
                  style={{ backgroundColor: colors.primary + "20" }}
                >
                  <IconSymbol size={24} name="music.note" color={colors.primary} />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Audio</Text>
                  <Text className="text-xs text-muted mt-1">Scan audio files</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => handlePickFile("video")}
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderWidth: 2,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 12,
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <View
                  className="w-12 h-12 rounded-full items-center justify-center mr-3"
                  style={{ backgroundColor: colors.primary + "20" }}
                >
                  <IconSymbol size={24} name="video.fill" color={colors.primary} />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Videos</Text>
                  <Text className="text-xs text-muted mt-1">Scan video files</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => setScanMode(null)}
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderWidth: 1,
                  borderRadius: 12,
                  padding: 14,
                  marginTop: 8,
                }}
              >
                <Text className="text-center font-semibold text-foreground">Back</Text>
              </TouchableOpacity>
            </>
          ) : scanMode === "picking" ? (
            <>
              <View className="items-center py-12">
                <ActivityIndicator size="large" color={colors.primary} />
                <Text className="text-lg font-semibold text-foreground mt-6">Opening file browser...</Text>
                <Text className="text-sm text-muted mt-2">Select a file from your device</Text>
              </View>
            </>
          ) : scanMode === "scanning" ? (
            <>
              <View className="items-center py-12">
                <View
                  className="w-24 h-24 rounded-full items-center justify-center mb-6"
                  style={{ backgroundColor: colors.primary + "20" }}
                >
                  <IconSymbol size={48} name="shield.fill" color={colors.primary} />
                </View>
                <Text className="text-2xl font-bold text-foreground mb-2">Analyzing...</Text>
                <Text className="text-sm text-muted mb-6">{Math.round(scanProgress)}% Complete</Text>

                <View className="w-full h-3 bg-border rounded-full overflow-hidden mb-6">
                  <View
                    className="h-full rounded-full"
                    style={{
                      backgroundColor: colors.primary,
                      width: `${Math.min(scanProgress, 100)}%`,
                    }}
                  />
                </View>

                <Text className="text-xs text-muted text-center">
                  {selectedFile ? `Scanning: ${selectedFile.name}` : "Analyzing file..."}
                </Text>
              </View>
            </>
          ) : scanMode === "results" && analysisResult ? (
            <>
              <View className="mb-6">
                <View
                  className="rounded-2xl p-6 mb-6"
                  style={{
                    backgroundColor:
                      analysisResult.threatLevel === "threat" ||
                      analysisResult.threatLevel === "suspicious"
                        ? colors.error + "20"
                        : colors.success + "20",
                    borderColor:
                      analysisResult.threatLevel === "threat" ||
                      analysisResult.threatLevel === "suspicious"
                        ? colors.error
                        : colors.success,
                    borderWidth: 2,
                  }}
                >
                  <View className="flex-row items-center justify-between mb-3">
                    <Text className="text-lg font-semibold text-foreground">Scan Complete</Text>
                    <IconSymbol
                      size={24}
                      name={getStatusIcon(analysisResult.threatLevel)}
                      color={getStatusColor(analysisResult.threatLevel)}
                    />
                  </View>
                  <Text className="text-sm text-muted">{analysisResult.details}</Text>
                </View>

                {/* File Details */}
                <View className="bg-surface rounded-2xl p-4 border border-border mb-4">
                  <Text className="text-sm font-semibold text-foreground mb-3">File Details</Text>

                  <View className="mb-3">
                    <Text className="text-xs text-muted">Name</Text>
                    <Text className="text-sm font-semibold text-foreground">{analysisResult.file.name}</Text>
                  </View>

                  <View className="mb-3">
                    <Text className="text-xs text-muted">Size</Text>
                    <Text className="text-sm font-semibold text-foreground">
                      {FilePickerService.formatFileSize(analysisResult.file.size)}
                    </Text>
                  </View>

                  <View className="mb-3">
                    <Text className="text-xs text-muted">Type</Text>
                    <Text className="text-sm font-semibold text-foreground capitalize">
                      {analysisResult.file.type}
                    </Text>
                  </View>

                  <View>
                    <Text className="text-xs text-muted">MIME Type</Text>
                    <Text className="text-sm font-semibold text-foreground">{analysisResult.file.mimeType}</Text>
                  </View>
                </View>

                {/* Risk Factors */}
                {analysisResult.riskFactors.length > 0 && (
                  <View className="bg-warning opacity-10 rounded-2xl p-4 border border-warning mb-4">
                    <Text className="text-sm font-semibold text-foreground mb-2">Risk Factors</Text>
                    {analysisResult.riskFactors.map((factor, idx) => (
                      <View key={idx} className="flex-row items-center mb-2">
                        <IconSymbol size={16} name="exclamationmark.triangle.fill" color={colors.warning} />
                        <Text className="text-xs text-muted ml-2">{factor}</Text>
                      </View>
                    ))}
                  </View>
                )}

                {/* Safe Status */}
                {analysisResult.threatLevel === "safe" && (
                  <View className="bg-success opacity-10 rounded-2xl p-4 border border-success">
                    <View className="flex-row items-center">
                      <IconSymbol size={20} name="checkmark.circle.fill" color={colors.success} />
                      <Text className="text-sm font-semibold text-foreground ml-2">File is safe</Text>
                    </View>
                  </View>
                )}
              </View>

              {/* Action Buttons */}
              <TouchableOpacity
                onPress={() => {
                  setScanMode(null);
                  setSelectedFile(null);
                  setAnalysisResult(null);
                }}
                style={{
                  backgroundColor: colors.primary,
                  borderRadius: 12,
                  padding: 14,
                  marginBottom: 12,
                }}
              >
                <Text className="text-center font-semibold text-white">Scan Another File</Text>
              </TouchableOpacity>
            </>
          ) : null}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
