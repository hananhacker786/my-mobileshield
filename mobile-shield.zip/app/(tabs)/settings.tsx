import { ScrollView, Text, View, TouchableOpacity, Pressable, Switch } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import * as Haptics from "expo-haptics";
import { useState } from "react";

export default function SettingsScreen() {
  const colors = useColors();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [autoScan, setAutoScan] = useState(true);
  const [biometricLock, setBiometricLock] = useState(false);

  const handleToggle = (value: boolean, setter: (val: boolean) => void) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setter(value);
  };

  const settingSections = [
    {
      title: "Account",
      items: [
        {
          icon: "person.fill",
          label: "Profile",
          value: "user@example.com",
          onPress: () => {},
        },
        {
          icon: "lock.fill",
          label: "Change Password",
          value: "",
          onPress: () => {},
        },
      ],
    },
    {
      title: "Security",
      items: [
        {
          icon: "bell.fill",
          label: "Notifications",
          toggle: true,
          value: notificationsEnabled,
          onToggle: (val: boolean) => handleToggle(val, setNotificationsEnabled),
        },
        {
          icon: "lock.fill",
          label: "Biometric Lock",
          toggle: true,
          value: biometricLock,
          onToggle: (val: boolean) => handleToggle(val, setBiometricLock),
        },
        {
          icon: "checkmark.shield.fill",
          label: "Auto Scan",
          toggle: true,
          value: autoScan,
          onToggle: (val: boolean) => handleToggle(val, setAutoScan),
        },
      ],
    },
    {
      title: "Preferences",
      items: [
        {
          icon: "gearshape.fill",
          label: "Scan Frequency",
          value: "Daily",
          onPress: () => {},
        },
        {
          icon: "eye.fill",
          label: "Dark Mode",
          toggle: true,
          value: darkMode,
          onToggle: (val: boolean) => handleToggle(val, setDarkMode),
        },
      ],
    },
    {
      title: "About",
      items: [
        {
          icon: "exclamationmark.triangle.fill",
          label: "About Mobile Shield",
          value: "v1.0.0",
          onPress: () => {},
        },
        {
          icon: "questionmark.circle.fill",
          label: "Help & Support",
          value: "",
          onPress: () => {},
        },
        {
          icon: "arrow.up.right",
          label: "Privacy Policy",
          value: "",
          onPress: () => {},
        },
        {
          icon: "arrow.up.right",
          label: "Terms of Service",
          value: "",
          onPress: () => {},
        },
      ],
    },
  ];

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary px-6 pt-6 pb-8">
          <Text className="text-3xl font-bold text-white mb-2">Settings</Text>
          <Text className="text-sm text-white opacity-80">Manage your account and preferences</Text>
        </View>

        {/* Content */}
        <View className="px-6 py-6">
          {settingSections.map((section, sectionIdx) => (
            <View key={sectionIdx} className="mb-6">
              <Text className="text-lg font-semibold text-foreground mb-3">{section.title}</Text>

              {section.items.map((item, itemIdx) => (
                <Pressable
                  key={itemIdx}
                  onPress={item.onPress}
                  style={({ pressed }) => [
                    {
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      borderWidth: 1,
                      borderRadius: 12,
                      padding: 12,
                      marginBottom: 8,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <View className="flex-row items-center justify-between">
                    <View className="flex-row items-center flex-1">
                      <View
                        className="w-10 h-10 rounded-full items-center justify-center mr-3"
                        style={{ backgroundColor: colors.primary + "20" }}
                      >
                        <IconSymbol size={20} name={item.icon as any} color={colors.primary} />
                      </View>
                      <View className="flex-1">
                        <Text className="text-sm font-semibold text-foreground">{item.label}</Text>
                        {item.value && !item.toggle && (
                          <Text className="text-xs text-muted mt-1">{item.value}</Text>
                        )}
                      </View>
                    </View>
                    {item.toggle ? (
                      <Switch
                        value={item.value as boolean}
                        onValueChange={item.onToggle}
                        trackColor={{ false: colors.border, true: colors.primary + "80" }}
                        thumbColor={item.value ? colors.primary : colors.muted}
                      />
                    ) : (
                      <IconSymbol size={20} name="chevron.right" color={colors.muted} />
                    )}
                  </View>
                </Pressable>
              ))}
            </View>
          ))}

          {/* Logout Button */}
          <TouchableOpacity
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            }}
            style={{
              backgroundColor: colors.error,
              borderRadius: 12,
              padding: 14,
              marginTop: 8,
              marginBottom: 24,
            }}
          >
            <Text className="text-center font-semibold text-white">Logout</Text>
          </TouchableOpacity>

          {/* App Info */}
          <View className="bg-surface rounded-2xl p-4 border border-border text-center items-center">
            <Text className="text-xs text-muted">Mobile Shield v1.0.0</Text>
            <Text className="text-xs text-muted mt-1">Security. Elevated.</Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
