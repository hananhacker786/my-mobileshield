import { ScrollView, Text, View, TouchableOpacity, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import * as Haptics from "expo-haptics";
import { useState } from "react";

interface Plan {
  id: string;
  name: string;
  price: string;
  period: string;
  features: string[];
  popular?: boolean;
}

export default function FeaturesScreen() {
  const colors = useColors();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isPremium, setIsPremium] = useState(false);

  const plans: Plan[] = [
    {
      id: "free",
      name: "Free",
      price: "$0",
      period: "Forever",
      features: [
        "Single file/app scanning",
        "Basic threat detection",
        "Scan history",
        "Device status monitoring",
      ],
    },
    {
      id: "weekly",
      name: "Weekly",
      price: "$2.99",
      period: "per week",
      popular: true,
      features: [
        "Full device scanning",
        "Real-time app monitoring",
        "Privacy leak scanner",
        "Thief lock protection",
        "Background monitoring",
        "Priority support",
      ],
    },
    {
      id: "monthly",
      name: "Monthly",
      price: "$9.99",
      period: "per month",
      features: [
        "Full device scanning",
        "Real-time app monitoring",
        "Privacy leak scanner",
        "Thief lock protection",
        "Background monitoring",
        "Priority support",
        "Advanced threat analysis",
      ],
    },
    {
      id: "yearly",
      name: "Yearly",
      price: "$79.99",
      period: "per year",
      features: [
        "Full device scanning",
        "Real-time app monitoring",
        "Privacy leak scanner",
        "Thief lock protection",
        "Background monitoring",
        "Priority support",
        "Advanced threat analysis",
        "Lifetime updates",
      ],
    },
  ];

  const premiumFeatures = [
    {
      icon: "shield.fill",
      title: "Full Device Scan",
      description: "Comprehensive scan of your entire device for threats",
    },
    {
      icon: "chart.bar.fill",
      title: "Background Monitoring",
      description: "Real-time monitoring of app usage and system activity",
    },
    {
      icon: "eye.fill",
      title: "Privacy Leak Scanner",
      description: "Detect unauthorized camera, microphone, and network access",
    },
    {
      icon: "lock.fill",
      title: "Thief Lock",
      description: "Protect your app with pattern lock or PIN",
    },
    {
      icon: "bell.fill",
      title: "Smart Notifications",
      description: "Daily security reminders and threat alerts",
    },
    {
      icon: "checkmark.shield.fill",
      title: "Advanced Detection",
      description: "AI-powered threat detection and analysis",
    },
  ];

  const handleSubscribe = (planId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSelectedPlan(planId);
    if (planId !== "free") {
      setIsPremium(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary px-6 pt-6 pb-8">
          <Text className="text-3xl font-bold text-white mb-2">Premium Features</Text>
          <Text className="text-sm text-white opacity-80">Unlock advanced security tools</Text>
        </View>

        {/* Content */}
        <View className="px-6 py-6">
          {/* Premium Features Grid */}
          <Text className="text-lg font-semibold text-foreground mb-4">What You Get</Text>

          {premiumFeatures.map((feature, index) => (
            <View key={index} className="flex-row items-start mb-4">
              <View
                className="w-12 h-12 rounded-full items-center justify-center mr-3"
                style={{ backgroundColor: colors.primary + "20" }}
              >
                <IconSymbol size={24} name={feature.icon as any} color={colors.primary} />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground">{feature.title}</Text>
                <Text className="text-xs text-muted mt-1">{feature.description}</Text>
              </View>
            </View>
          ))}

          {/* Pricing Plans */}
          <Text className="text-lg font-semibold text-foreground mb-4 mt-8">Choose Your Plan</Text>

          {plans.map((plan) => (
            <Pressable
              key={plan.id}
              onPress={() => handleSubscribe(plan.id)}
              style={({ pressed }) => [
                {
                  backgroundColor:
                    selectedPlan === plan.id || (plan.id === "free" && !isPremium)
                      ? colors.primary + "20"
                      : colors.surface,
                  borderColor:
                    selectedPlan === plan.id || (plan.id === "free" && !isPremium) ? colors.primary : colors.border,
                  borderWidth: 2,
                  borderRadius: 16,
                  padding: 16,
                  marginBottom: 12,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <View className="flex-row items-start justify-between mb-3">
                <View className="flex-1">
                  <View className="flex-row items-center mb-1">
                    <Text className="text-base font-semibold text-foreground">{plan.name}</Text>
                    {plan.popular && (
                      <View className="bg-warning rounded-full px-2 py-1 ml-2">
                        <Text className="text-xs font-bold text-white">POPULAR</Text>
                      </View>
                    )}
                  </View>
                  <Text className="text-2xl font-bold text-foreground">
                    {plan.price}
                    <Text className="text-sm text-muted font-normal"> {plan.period}</Text>
                  </Text>
                </View>
                {(selectedPlan === plan.id || (plan.id === "free" && !isPremium)) && (
                  <IconSymbol size={24} name="checkmark.circle.fill" color={colors.primary} />
                )}
              </View>

              <View>
                {plan.features.map((feature, idx) => (
                  <View key={idx} className="flex-row items-center mb-2">
                    <IconSymbol size={16} name="checkmark.circle.fill" color={colors.success} />
                    <Text className="text-xs text-muted ml-2">{feature}</Text>
                  </View>
                ))}
              </View>
            </Pressable>
          ))}

          {/* YouTube Free Trial */}
          <View className="bg-warning opacity-10 rounded-2xl p-4 border border-warning mt-6 mb-6">
            <View className="flex-row items-start">
              <IconSymbol size={20} name="bell.fill" color={colors.warning} />
              <View className="flex-1 ml-3">
                <Text className="text-sm font-semibold text-foreground">YouTube Free Trial</Text>
                <Text className="text-xs text-muted mt-1">
                  Subscribe to our YouTube channel @skhanangaming to get 1 week of premium access for free!
                </Text>
                <TouchableOpacity
                  style={{
                    backgroundColor: colors.warning,
                    borderRadius: 8,
                    paddingVertical: 8,
                    paddingHorizontal: 12,
                    marginTop: 8,
                    alignSelf: "flex-start",
                  }}
                >
                  <Text className="text-xs font-semibold text-white">Visit Channel</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>

          {/* Subscribe Button */}
          {selectedPlan && selectedPlan !== "free" && (
            <TouchableOpacity
              onPress={() => {
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              }}
              style={{
                backgroundColor: colors.primary,
                borderRadius: 12,
                padding: 14,
                marginBottom: 12,
              }}
            >
              <Text className="text-center font-semibold text-white">Subscribe Now</Text>
            </TouchableOpacity>
          )}

          {/* Manage Subscription */}
          {isPremium && (
            <TouchableOpacity
              style={{
                backgroundColor: colors.surface,
                borderColor: colors.border,
                borderWidth: 1,
                borderRadius: 12,
                padding: 14,
                marginBottom: 12,
              }}
            >
              <Text className="text-center font-semibold text-foreground">Manage Subscription</Text>
            </TouchableOpacity>
          )}

          {/* FAQ */}
          <View className="mt-8 mb-8">
            <Text className="text-lg font-semibold text-foreground mb-4">Frequently Asked Questions</Text>

            <View className="bg-surface rounded-2xl p-4 border border-border mb-3">
              <Text className="text-sm font-semibold text-foreground mb-2">Can I cancel anytime?</Text>
              <Text className="text-xs text-muted">
                Yes, you can cancel your subscription at any time. No hidden fees or long-term commitments.
              </Text>
            </View>

            <View className="bg-surface rounded-2xl p-4 border border-border mb-3">
              <Text className="text-sm font-semibold text-foreground mb-2">Is my data private?</Text>
              <Text className="text-xs text-muted">
                All scans are performed locally on your device. We never upload your personal data to our servers.
              </Text>
            </View>

            <View className="bg-surface rounded-2xl p-4 border border-border">
              <Text className="text-sm font-semibold text-foreground mb-2">Do you offer refunds?</Text>
              <Text className="text-xs text-muted">
                We offer a 7-day money-back guarantee if you're not satisfied with our service.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
