import { View, Text, TouchableOpacity, Image } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

export default function SplashScreen() {
  const colors = useColors();
  const router = useRouter();

  const handleGetStarted = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.replace("../login");
  };

  return (
    <ScreenContainer className="p-6" edges={["top", "bottom", "left", "right"]}>
      <View className="flex-1 items-center justify-center">
        {/* Logo */}
        <View
          className="w-32 h-32 rounded-full items-center justify-center mb-8"
          style={{ backgroundColor: colors.primary + "20" }}
        >
          <Image
            source={require("@/assets/images/icon.png")}
            style={{ width: 120, height: 120 }}
            resizeMode="contain"
          />
        </View>

        {/* Title */}
        <Text className="text-4xl font-bold text-foreground text-center mb-2">Mobile Shield</Text>
        <Text className="text-lg text-primary text-center font-semibold mb-6">Security. Elevated.</Text>

        {/* Description */}
        <View className="bg-surface rounded-2xl p-6 mb-8 border border-border">
          <Text className="text-sm text-foreground text-center leading-relaxed">
            Protect your device from threats with advanced scanning, real-time monitoring, and privacy protection.
          </Text>
        </View>

        {/* Features List */}
        <View className="w-full mb-8">
          <View className="flex-row items-center mb-4">
            <View
              className="w-8 h-8 rounded-full items-center justify-center mr-3"
              style={{ backgroundColor: colors.success + "20" }}
            >
              <Text className="text-xs font-bold text-success">✓</Text>
            </View>
            <Text className="text-sm text-foreground">Scan files and apps for threats</Text>
          </View>

          <View className="flex-row items-center mb-4">
            <View
              className="w-8 h-8 rounded-full items-center justify-center mr-3"
              style={{ backgroundColor: colors.success + "20" }}
            >
              <Text className="text-xs font-bold text-success">✓</Text>
            </View>
            <Text className="text-sm text-foreground">Real-time app monitoring</Text>
          </View>

          <View className="flex-row items-center">
            <View
              className="w-8 h-8 rounded-full items-center justify-center mr-3"
              style={{ backgroundColor: colors.success + "20" }}
            >
              <Text className="text-xs font-bold text-success">✓</Text>
            </View>
            <Text className="text-sm text-foreground">Privacy leak detection</Text>
          </View>
        </View>
      </View>

      {/* Get Started Button */}
      <TouchableOpacity
        onPress={handleGetStarted}
        style={{
          backgroundColor: colors.primary,
          borderRadius: 12,
          padding: 16,
          marginBottom: 12,
        }}
      >
        <Text className="text-center font-semibold text-white text-base">Get Started</Text>
      </TouchableOpacity>

      {/* Already have account */}
      <TouchableOpacity
        onPress={() => router.replace("../login")}
        style={{
          backgroundColor: colors.surface,
          borderColor: colors.border,
          borderWidth: 1,
          borderRadius: 12,
          padding: 16,
        }}
      >
        <Text className="text-center font-semibold text-foreground">Already have an account?</Text>
      </TouchableOpacity>
    </ScreenContainer>
  );
}
