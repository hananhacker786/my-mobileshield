# Mobile Shield - App Design Document

## Overview
Mobile Shield is a comprehensive mobile security app that provides users with tools to scan for threats, monitor app usage, detect privacy leaks, and protect their device with app-level security features.

## Design Principles
- **Mobile-First**: Designed for portrait orientation (9:16) with one-handed usage in mind
- **iOS-Native Feel**: Follows Apple Human Interface Guidelines for a polished, first-party app experience
- **Clear Information Hierarchy**: Security status and actions are immediately visible
- **Progressive Disclosure**: Advanced features revealed only when needed
- **Trust Through Transparency**: Users understand what's being scanned and why

## Color Palette
- **Primary Blue**: `#0a7ea4` - Trust, security, and professionalism
- **Success Green**: `#22C55E` - Safe/clean status
- **Warning Orange**: `#F59E0B` - Caution/potential threats
- **Error Red**: `#EF4444` - Danger/threats detected
- **Background**: `#ffffff` (light) / `#151718` (dark)
- **Surface**: `#f5f5f5` (light) / `#1e2022` (dark)

## Screen List

### 1. Splash / Onboarding Screen
- App logo and tagline ("Security. Elevated.")
- Quick onboarding slides explaining core features
- "Get Started" button to proceed to authentication

### 2. Authentication Screens
- **Login Screen**: Email/password login with "Sign in with Gmail" button
- **Register Screen**: Email, password, confirm password with "Sign up with Gmail" option
- **Forgot Password**: Email recovery flow

### 3. Home Dashboard
- Security Status Card (overall device health: Safe/At Risk/Threats Detected)
- Quick Action Buttons:
  - Scan Single File/App (Free)
  - Scan Full Device (Premium)
  - Upgrade Plan
- Recent Scan Results Summary
- Notification Badge (if threats found)
- Bottom Tab Navigation

### 4. Single Scan Screen (Free Feature)
- File/App Selection Interface
- Permission Request Dialog
- Scan Progress Indicator
- Results Screen:
  - Threat Status (Safe/Threats Found)
  - Detailed Findings List
  - Delete/Keep Actions for Threats
  - Scan History

### 5. Full Device Scan Screen (Premium Feature)
- Permission Request Dialog
- Scan Progress with Percentage
- Real-Time Threat Counter
- Scan Results:
  - Summary Statistics
  - Threats by Category
  - Detailed Threat List with Actions
  - Quarantine/Delete Options

### 6. Background Monitoring Screen (Premium)
- Real-Time App Usage Chart
- Recently Used Apps List
- App Activity Timeline
- Permission Monitoring Status
- Enable/Disable Toggle

### 7. Privacy Leak Scanner Screen (Premium)
- Permission Request Dialog
- Scan Status:
  - Camera Access Check
  - Microphone Access Check
  - Network Connections Check
- Findings List
- Remediation Actions

### 8. Thief Lock Screen (Premium)
- Lock Setup Interface
- Pattern Lock / PIN Setup
- Lock Status Indicator
- Unlock Dialog (when app is reopened)
- Lock History/Attempts Log

### 9. Subscription / Upgrade Plan Screen
- Plan Comparison Card:
  - Free Plan (Current/Active)
  - Weekly Plan ($2.99)
  - Monthly Plan ($9.99)
  - Yearly Plan ($79.99)
- YouTube Channel Free Trial Offer
- Subscribe Button for Each Plan
- Manage Subscription Link

### 10. Settings Screen
- Account Information
- Notification Preferences
- Scan Frequency Settings
- Privacy & Security Settings
- About & Help
- Logout

### 11. Notification Center
- Morning Security Reminder
- Threat Alerts
- Scan Completion Notifications
- YouTube Channel Subscription Reminder

## Key User Flows

### Flow 1: Free Single File Scan
1. User taps "Scan Single File/App" on Home
2. App requests file system permission
3. User selects file/app from device
4. App performs scan (simulated)
5. Results displayed with threat status
6. User can delete threat or keep file
7. Scan added to history

### Flow 2: Premium Full Device Scan
1. User taps "Scan Full Device"
2. If not subscribed, redirected to Upgrade Plan
3. If subscribed, app requests permission
4. Scan progresses with real-time counter
5. Results show summary and detailed threats
6. User can quarantine or delete threats

### Flow 3: Subscribe to Premium Plan
1. User taps "Upgrade Plan"
2. Views plan comparison
3. Sees YouTube free trial offer
4. Selects a plan (Weekly/Monthly/Yearly)
5. Completes payment
6. Receives confirmation
7. Premium features unlocked

### Flow 4: YouTube Free Trial
1. User sees "Subscribe to YouTube for 1 Week Free"
2. Taps to open YouTube channel link
3. User subscribes on YouTube
4. Returns to app
5. Verifies subscription (manual or automatic)
6. Receives 1-week free premium access

### Flow 5: Thief Lock Setup
1. User taps "Thief Lock" in Premium Features
2. Selects lock type (Pattern/PIN/Biometric)
3. Sets up lock
4. Lock is activated
5. On next app open, user prompted to unlock
6. Failed attempts logged

## Typography
- **Display**: 32px, Bold (screen titles)
- **Headline**: 24px, Bold (section headers)
- **Subheading**: 18px, Semibold (card titles)
- **Body**: 16px, Regular (main text)
- **Caption**: 14px, Regular (secondary text)
- **Small**: 12px, Regular (hints, labels)

## Spacing & Layout
- **Padding**: 16px (standard), 24px (large sections)
- **Gap**: 12px (between items), 16px (between sections)
- **Border Radius**: 12px (cards), 8px (buttons), 4px (inputs)
- **Safe Area**: Respected on all screens using ScreenContainer

## Interactive Elements
- **Buttons**: Primary (blue), Secondary (outline), Danger (red)
- **Cards**: Elevated with subtle shadow, 12px border radius
- **Toggles**: Smooth animation, haptic feedback
- **Progress Indicators**: Circular for scans, linear for multi-step processes
- **Modals**: Half-sheet for permissions, full-screen for results

## Accessibility
- Minimum touch target: 44x44pt
- Color contrast: WCAG AA compliant
- Text scaling: Supports dynamic type
- Haptic feedback: Enabled for critical actions
- VoiceOver support: All interactive elements labeled

## Performance Considerations
- Lazy load premium feature screens
- Cache scan results locally
- Batch permission requests
- Optimize list rendering with FlatList
- Debounce search/filter operations
