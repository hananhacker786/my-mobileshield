import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system";
import * as MediaLibrary from "expo-media-library";

export interface PickedFile {
  uri: string;
  name: string;
  size: number;
  mimeType: string;
  type: "image" | "audio" | "video" | "document" | "app" | "other";
  extension: string;
}

export interface FileAnalysis {
  file: PickedFile;
  threatLevel: "safe" | "suspicious" | "threat";
  details: string;
  riskFactors: string[];
}

export class FilePickerService {
  /**
   * Pick a single file from device
   */
  static async pickFile(): Promise<PickedFile | null> {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "*/*",
        copyToCacheDirectory: true,
      });

      if (result.canceled) {
        return null;
      }

      const asset = result.assets[0];
      if (!asset) return null;

      return this.parsePickedFile(asset);
    } catch (error) {
      console.error("Error picking file:", error);
      return null;
    }
  }

  /**
   * Pick image from device
   */
  static async pickImage(): Promise<PickedFile | null> {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "image/*",
        copyToCacheDirectory: true,
      });

      if (result.canceled) {
        return null;
      }

      const asset = result.assets[0];
      if (!asset) return null;

      return this.parsePickedFile(asset);
    } catch (error) {
      console.error("Error picking image:", error);
      return null;
    }
  }

  /**
   * Pick audio file from device
   */
  static async pickAudio(): Promise<PickedFile | null> {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "audio/*",
        copyToCacheDirectory: true,
      });

      if (result.canceled) {
        return null;
      }

      const asset = result.assets[0];
      if (!asset) return null;

      return this.parsePickedFile(asset);
    } catch (error) {
      console.error("Error picking audio:", error);
      return null;
    }
  }

  /**
   * Pick video file from device
   */
  static async pickVideo(): Promise<PickedFile | null> {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "video/*",
        copyToCacheDirectory: true,
      });

      if (result.canceled) {
        return null;
      }

      const asset = result.assets[0];
      if (!asset) return null;

      return this.parsePickedFile(asset);
    } catch (error) {
      console.error("Error picking video:", error);
      return null;
    }
  }

  /**
   * Analyze picked file for threats
   */
  static async analyzeFile(file: PickedFile): Promise<FileAnalysis> {
    const riskFactors: string[] = [];
    let threatLevel: "safe" | "suspicious" | "threat" = "safe";

    // Check file size (very large files can be suspicious)
    if (file.size > 500 * 1024 * 1024) {
      // > 500MB
      riskFactors.push("Unusually large file size");
      threatLevel = "suspicious";
    }

    // Check for suspicious extensions
    const suspiciousExtensions = [
      ".exe",
      ".apk",
      ".deb",
      ".msi",
      ".bat",
      ".cmd",
      ".com",
      ".scr",
      ".vbs",
      ".js",
      ".jar",
    ];
    if (suspiciousExtensions.some((ext) => file.extension.toLowerCase().endsWith(ext))) {
      riskFactors.push("Executable file detected");
      if (threatLevel === "safe") threatLevel = "suspicious";
    }

    // Check for double extensions (common malware tactic)
    const nameWithoutExt = file.name.split(".").slice(0, -1).join(".");
    if (nameWithoutExt.includes(".")) {
      riskFactors.push("Double extension detected");
      if (threatLevel === "safe") threatLevel = "suspicious";
    }

    // Simulate threat detection (10% chance of threat)
    if (Math.random() < 0.1) {
      riskFactors.push("Malware signature detected");
      threatLevel = "threat";
    }

    // Simulate suspicious detection (20% chance)
    if (threatLevel === "safe" && Math.random() < 0.2) {
      riskFactors.push("Suspicious behavior pattern");
      threatLevel = "suspicious";
    }

    const details =
      threatLevel === "safe"
        ? "File appears to be safe"
        : threatLevel === "suspicious"
          ? "File has suspicious characteristics"
          : "File contains potential threats";

    return {
      file,
      threatLevel,
      details,
      riskFactors,
    };
  }

  /**
   * Parse DocumentPicker asset into PickedFile
   */
  private static parsePickedFile(asset: any): PickedFile {
    const name = asset.name || "unknown";
    const uri = asset.uri;
    const size = asset.size || 0;
    const mimeType = asset.mimeType || "application/octet-stream";

    // Extract extension
    const extension = name.includes(".") ? "." + name.split(".").pop() : "";

    // Determine file type
    let type: PickedFile["type"] = "other";
    if (mimeType.startsWith("image/")) {
      type = "image";
    } else if (mimeType.startsWith("audio/")) {
      type = "audio";
    } else if (mimeType.startsWith("video/")) {
      type = "video";
    } else if (
      mimeType.includes("document") ||
      mimeType.includes("pdf") ||
      mimeType.includes("word") ||
      mimeType.includes("sheet")
    ) {
      type = "document";
    } else if (
      mimeType.includes("application/vnd.android.package-archive") ||
      extension.toLowerCase() === ".apk"
    ) {
      type = "app";
    }

    return {
      uri,
      name,
      size,
      mimeType,
      type,
      extension,
    };
  }

  /**
   * Format file size for display
   */
  static formatFileSize(bytes: number): string {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
  }

  /**
   * Get file type icon name
   */
  static getFileTypeIcon(type: PickedFile["type"]): string {
    switch (type) {
      case "image":
        return "photo";
      case "audio":
        return "music-note";
      case "video":
        return "videocam";
      case "document":
        return "description";
      case "app":
        return "apps";
      default:
        return "insert-drive-file";
    }
  }
}
