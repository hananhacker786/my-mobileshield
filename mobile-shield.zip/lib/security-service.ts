/**
 * Security Service - Handles threat detection and scanning logic
 * This is a simulated service for the prototype
 */

export interface ThreatSignature {
  id: string;
  name: string;
  severity: "low" | "medium" | "high" | "critical";
  description: string;
}

export interface ScanResult {
  itemId: string;
  itemName: string;
  itemType: "app" | "file";
  threatLevel: "safe" | "suspicious" | "threat";
  threatsFound: ThreatSignature[];
  scanTime: number; // in milliseconds
}

// Mock threat signatures database
const THREAT_SIGNATURES: ThreatSignature[] = [
  {
    id: "malware_001",
    name: "Trojan.Generic",
    severity: "critical",
    description: "Generic trojan malware detected",
  },
  {
    id: "malware_002",
    name: "Adware.Aggressive",
    severity: "high",
    description: "Aggressive adware with tracking capabilities",
  },
  {
    id: "malware_003",
    name: "PUP.Suspicious",
    severity: "medium",
    description: "Potentially unwanted program",
  },
  {
    id: "malware_004",
    name: "Spyware.Monitor",
    severity: "high",
    description: "Spyware with monitoring capabilities",
  },
  {
    id: "malware_005",
    name: "Ransomware.Crypto",
    severity: "critical",
    description: "Ransomware with encryption capabilities",
  },
];

export class SecurityService {
  /**
   * Simulate scanning a single item (app or file)
   */
  static async scanItem(itemId: string, itemName: string, itemType: "app" | "file"): Promise<ScanResult> {
    const startTime = Date.now();

    // Simulate scan delay (500-2000ms)
    await this.delay(Math.random() * 1500 + 500);

    // Simulate threat detection (20% chance of threat, 30% chance of suspicious)
    const random = Math.random();
    let threatLevel: "safe" | "suspicious" | "threat" = "safe";
    let threatsFound: ThreatSignature[] = [];

    if (random < 0.2) {
      threatLevel = "threat";
      const threatCount = Math.floor(Math.random() * 2) + 1;
      threatsFound = this.getRandomThreats(threatCount, "critical");
    } else if (random < 0.5) {
      threatLevel = "suspicious";
      const threatCount = Math.floor(Math.random() * 2) + 1;
      threatsFound = this.getRandomThreats(threatCount, "medium");
    }

    return {
      itemId,
      itemName,
      itemType,
      threatLevel,
      threatsFound,
      scanTime: Date.now() - startTime,
    };
  }

  /**
   * Simulate scanning multiple items
   */
  static async scanItems(
    items: Array<{ id: string; name: string; type: "app" | "file" }>
  ): Promise<ScanResult[]> {
    const results: ScanResult[] = [];

    for (const item of items) {
      const result = await this.scanItem(item.id, item.name, item.type);
      results.push(result);
    }

    return results;
  }

  /**
   * Simulate full device scan
   */
  static async scanFullDevice(progressCallback?: (progress: number) => void): Promise<ScanResult[]> {
    const mockItems = [
      { id: "app_1", name: "Instagram", type: "app" as const },
      { id: "app_2", name: "WhatsApp", type: "app" as const },
      { id: "app_3", name: "Chrome", type: "app" as const },
      { id: "app_4", name: "Facebook", type: "app" as const },
      { id: "app_5", name: "TikTok", type: "app" as const },
      { id: "file_1", name: "document.pdf", type: "file" as const },
      { id: "file_2", name: "image.jpg", type: "file" as const },
      { id: "file_3", name: "video.mp4", type: "file" as const },
      { id: "file_4", name: "archive.zip", type: "file" as const },
      { id: "file_5", name: "unknown.exe", type: "file" as const },
    ];

    const results: ScanResult[] = [];
    const totalItems = mockItems.length;

    for (let i = 0; i < totalItems; i++) {
      const item = mockItems[i];
      const result = await this.scanItem(item.id, item.name, item.type);
      results.push(result);

      if (progressCallback) {
        progressCallback(((i + 1) / totalItems) * 100);
      }
    }

    return results;
  }

  /**
   * Check for privacy leaks (camera, microphone, network)
   */
  static async checkPrivacyLeaks(): Promise<{
    cameraAccess: boolean;
    microphoneAccess: boolean;
    networkConnections: string[];
  }> {
    await this.delay(1000);

    return {
      cameraAccess: Math.random() < 0.1, // 10% chance of unauthorized access
      microphoneAccess: Math.random() < 0.1,
      networkConnections: Math.random() < 0.2 ? ["192.168.1.100", "10.0.0.50"] : [],
    };
  }

  /**
   * Simulate app usage monitoring
   */
  static async getAppUsageStats(): Promise<
    Array<{
      appName: string;
      usageTime: number; // in minutes
      lastUsed: string;
      permissions: string[];
    }>
  > {
    await this.delay(500);

    return [
      {
        appName: "Instagram",
        usageTime: 120,
        lastUsed: "5 minutes ago",
        permissions: ["Camera", "Microphone", "Location"],
      },
      {
        appName: "WhatsApp",
        usageTime: 90,
        lastUsed: "10 minutes ago",
        permissions: ["Camera", "Microphone", "Contacts"],
      },
      {
        appName: "Chrome",
        usageTime: 240,
        lastUsed: "2 minutes ago",
        permissions: ["Location", "Microphone"],
      },
      {
        appName: "Gmail",
        usageTime: 45,
        lastUsed: "1 hour ago",
        permissions: ["Contacts", "Calendar"],
      },
      {
        appName: "Maps",
        usageTime: 60,
        lastUsed: "3 hours ago",
        permissions: ["Location", "Camera"],
      },
    ];
  }

  /**
   * Helper: Get random threats
   */
  private static getRandomThreats(count: number, severity?: string): ThreatSignature[] {
    const threats = severity
      ? THREAT_SIGNATURES.filter((t) => t.severity === severity)
      : THREAT_SIGNATURES;

    const selected: ThreatSignature[] = [];
    for (let i = 0; i < Math.min(count, threats.length); i++) {
      const randomIndex = Math.floor(Math.random() * threats.length);
      selected.push(threats[randomIndex]);
    }
    return selected;
  }

  /**
   * Helper: Delay function
   */
  private static delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
